#Isaac R. Ward, 21727952
#Proof of work timer demonstrates how a network can evolve to cause the mining/proof of work algorithm
#to be easier or more difficult
from crypto3002 import *

if __name__ == '__main__':
    #Find how long the user wants one batch of mines to take
    desiredTime = input("Enter amount of time one mine should take in seconds as a float:\n")
    batchSize = input("Enter number of successes before target recalculation occurs as an integer (larger numbers will yield more accurate results on average, bitcoin uses a batch size of 2016):\n")
    suppress = input("Suppress per proof of work print? (y/n) (Will improve speed)\n")
    
    desiredBatchTime = float(desiredTime) * int(batchSize)
    
    #Make a person to transact from/to
    genRSAKeyPairs("proofOfWorkTimer")
    
    #Get parameters for proof of work algorithm
    #Start with the easiest possible target, will mine in one guess
    target = 2**255
        
    #A stop function normally used to cancel mining if the miner was beat by another miner
    stop = False
        
    #Begin testing
    print("Beginning testing, cancel at any time with a keyboard interupt.")
    successes = 0
    batchTime = 0
    
    print("Starting new batch:")
    while(True):
        #Announce
        if suppress == "n": 
            print("\tDoing proof of work on message " + str(successes + 1))
    
        #Generate an arbitrary transaction
        message = buildTransaction("privateKeys/privateproofOfWorkTimer.pem", "publicKeys/publicproofOfWorkTimer.pem", "publicKeys/publicproofOfWorkTimer.pem", successes)
        
        #Mine this message, output written to metrics
        metrics = {}
        proofOfWork(message, target, metrics, lambda: stop)
        if suppress == "n": 
            print("\tProof of work completed in " + str(metrics['t']) + " seconds. \n\tNeed " + str(float(desiredTime) - metrics['t']) + " more seconds.\n\tError: " + str(100*(metrics['t'] - float(desiredTime))/float(desiredTime)) + "%.")
        successes = successes + 1
        
        #Log the time it took to mine
        batchTime = batchTime + metrics['t']
        
        #When one batch worth of mines has been completed recalculate the target
        if(successes % int(batchSize) == 0):
            print("\nAnother " + str(batchSize) + " proof of works have been completed in " + str(batchTime) + " seconds. Need " + str(desiredBatchTime - batchTime) + " more seconds.")
            print("The average time to complete one proof of work in this batch was " + str(batchTime/float(batchSize)) + " seconds. Need " + str(batchTime/float(batchSize) - float(desiredTime)) + " more seconds. \n\tError: " + str(100*(batchTime - float(desiredBatchTime))/float(desiredBatchTime)) + "%.")
            print("**\nTarget being recalculated, changing\nfrom:\n" + str(target) + "\nto:")
            ratio = batchTime/desiredBatchTime
            target = ratio * target
            print(str(target) + "\n**")
            batchTime = 0
            print("Starting new batch:")
            

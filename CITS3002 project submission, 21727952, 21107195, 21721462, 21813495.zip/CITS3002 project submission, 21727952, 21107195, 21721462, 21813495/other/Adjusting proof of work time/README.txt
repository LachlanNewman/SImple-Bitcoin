#Isaac R. Ward, 21727952

This folder is strictly for running 'proofOfWorkTimer.py' which demonstrates
how the the network target can be recalculated to adjust the amount of 'effort' it
takes to mine a batch of transactions. 

This essentially means that as computational power increases, the target can be
decreased, increasing the difficulty and keeping the time it takes to mine an
arbitrarily specified number of transactions constant.

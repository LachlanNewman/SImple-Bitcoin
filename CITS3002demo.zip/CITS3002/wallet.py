import socket, ssl, pprint, uuid, subprocess, json, threading, sys, os
from crypto3002 import *
from blockchain3002 import *
from walletFunctions3002 import *

unminedTransactionList = []
publicPairList = []

def createSSLSocket():
    #Generate a stream style socket connection
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    #Require a certificate from the server. We used a self-signed certificate
    #so here ca_certs must be the server certificate itself.
    ssl_sock = ssl.wrap_socket(s,
                               ca_certs="mycert.pem",
                               cert_reqs=ssl.CERT_REQUIRED)
    
    #Get port number of server as user input and connect
    port = input("Enter server's port number:\n")
    ssl_sock.connect(('localhost', int(port)))
    
    return ssl_sock

def getUsersKeyPair():
    #Prompt the user to 'log in' with their private and public keys
    instructions = "Options: \n\t'e' to use existing keypair, \n\t'n' to generate new key pair.\n"
    option = input(instructions)
    while(option != "e" and option != "n"):
        print("Unrecognised option.")
        option = input(instructions)
    
    #Private will hold the private key as a string, public will hold the public key as a string
    private = ""
    public = ""
    
    #Depending on user option
    if(option == "e"):
        #Gets the file names form the user
        private = input("Enter the name of the .pem file holding your PRIVATE key data in current directory:\n")
        public = input("Enter the name of the .pem file holding your PUBLIC key data in current directory:\n")
        
    elif(option == "n"):
        #Generates new files given a symbolic name in the form: "private" + name + ".pem" and "public" + name + ".pem"
        name = input("Enter a symbolic identifier to name your key files with:\n")
        genRSAKeyPairs(name)
        
        #Saves the file names into variables private and public
        private = "private" + name + ".pem"
        public = "public" + name + ".pem"
        
        #Inform user of successful generation
        print("Files created successfully:")
        print("\tPrivate key saved in file private" + name + ".pem, keep this file secure!")
        print("\tPublic key saved in file public" + name + ".pem.")
        
    return [private, public]

#Receives any data from the server
def receive(ssl_sock, stopRecv):
    #Will be ran as a continuously looping thread that waits for received transmissions
    while not stopRecv():            
        #Load transmission
        transmission = json.loads(ssl_sock.recv(4096).decode()) #Up to 4KB of data
        
        #If nothing in loaded transmission, retry
        if not transmission:
            break

        #Obtain header to decide appropriate course of action
        #Only accepted headers FROM server TO client are:
            #TRANSACTION
            #MINING COMPLETE
        
        #Announce transmission received
        header = transmission['header']
        print("'" + header + "' received.")
        
        if(header == "TRANSACTION"):
            #The received transmission is a transaction, strip the header and save the transaction to a global list
            unminedTransactionList.append(transmission['data'])
                
        elif(header == "MINING COMPLETE"):
            #A miner has successfully mined a transaction, it needs to be written to the blockchain and removed from the unmined list
            blockchain.append(makeBlock(transmission['data']))
            
            t = transmission['data']['transaction']
            if t in unminedTransactionList: unminedTransactionList.remove(t)
            
        else:
            #Unrecognised header
            print("Unrecognised header '" + header + "', discarding transmission.")
    
    print("Ending transmission recieval thread.")
        
    
#Transmitting any data to the server
def transmit(ssl_sock, data, header):
    #Only accepted headers FROM client TO server are:
        #TRANSACTION
        #CLIENT SIGNAL
    
    #Build transmission as a dict
    transmission = {}
    transmission['data'] = data
    transmission['header'] = header
    
    #For testing purposes
    confirmation = input("Transmitting following transaction:\n\n" + json.dumps(transmission, indent = 4) + "\n\nConfirm? (y/n)\n")

    #Transmit to server
    if(confirmation == "y"):
        print("Transmitting...")
        #Send transmission
        ssl_sock.send(json.dumps(transmission).encode())   
    else:
        print("Cancelling transaction.")

#Creates a transaction with another user
def transact(srcPrivate, srcPublic):
    #Get the destination public key
    instructions  = "Enter the name of the .pem file holding the receiver's PUBLIC key data in current directory:\n"
    destPublic = input(instructions)
    
    #Get the amount the user wishes to send as an integer
    instructions = "Enter the (integer) number of coins you wish to send to the receiver:\n"
    amount = input(instructions)
    while(not amount.isdigit() or int(amount) < 0):
        print("Non integer and negative amounts are not recognised.\n")
        amount = input(instructions)
        
    #First check if the you have enough money to send this amount by looking at the blockchain
    srcPublicString = ""
    for line in open(srcPublic, 'r'):
        srcPublicString = srcPublicString + line
    
    if(checkBalance(blockchain, srcPublicString) < int(amount)):
        print("You do not have the required amount to send.")
        return -1
    
    #Build a signed transaction
    m = buildTransaction(srcPrivate, srcPublic, destPublic, amount)
    return m
    
#Main user input loop   
def mainProgramLoop(userPrivate, userPublic, ssl_sock):
    while(True):
        #Prompt the user to do an action
        instructions  = "Options: \n\t't' to transact with another user, \n\t'b' to view the blockchain, \n\t'bf' to view the blockchain with files names instead of key strings when possible, \n\t'c' to check the balances of all known users, \n\t'q' to quit.\n"
        option = input(instructions)
        while(option != "t" and option != "q" and option != "b" and option != "bf" and option != "c"):
            print("Unrecognised option.")
            option = input(instructions)
        
        #Execute appropriate function depending on option
        if(option == "q"):
            #Quit
            break
            
        elif(option  == "t"):
            #Transact
            #Build a signed transaction with user input
            t = transact(userPrivate, userPublic)
            #Send transaction to server to be retransmitted to network
            if(t != -1):
                transmit(ssl_sock, t, "TRANSACTION")

        elif(option == "b"):
            #View blockchain
            printBlockchain()
            
        elif(option == "bf"):
            #View blockchain with file names in the place of key strings when possible
            printBlockchainWithFileNames(publicPairList)
            
        elif(option == "c"):
            #View all known user's balances
            for u in publicPairList:
                userBalance = checkBalance(blockchain, u['string'])
                print("\t" + u['file'] + " has balance: " + str(userBalance))
                
            print("")
                    

#Returns a list of pairings between actual public keys and the names of the files they are in
def getPublicPairs(pairList):
    #Announce to user
    print("Reading .pem public key files from public keys directory.")
    
    #Find all files in that directory
    for pkfile in os.listdir("publicKeys"):
        #If they are .pem files
        if pkfile.endswith(".pem"):
            print("\tLoading " + str(pkfile))
        
            pair = {}
            
            #Get the filename
            pair['file'] = pkfile
            
            #Get the public key as a string
            pkString = ""
            for line in open(pkfile, 'r'):
                pkString = pkString + line
            pair['string']  = pkString
            
            #Add them to the given list
            pairList.append(pair)
            
    
#Execution begins here
if __name__ == '__main__':
    #Create a ssl socket connection to server
    ssl_sock = createSSLSocket()
    
    #Create an dictionary that maps user's public keys to the filenames that they are held in
    publicPairList = []
    getPublicPairs(publicPairList)
    
    #Get key pair filenames into variables
    privateFile, publicFile = getUsersKeyPair()
    #print(privatekey)
    #print(publickey)
    
    #lambda function used to stop the recieve thread when user specifies quit
    stopRecv = False
    
    #Start the receiving thread, as we must continuously monitor for incoming messages on the given socket
    receiveThread = threading.Thread(target=receive, args=(ssl_sock, lambda: stopRecv))
    receiveThread.start()  

    #Enter the main user control loop, only exiting by specifying quit, which will then stop the receive thread
    mainProgramLoop(privateFile, publicFile, ssl_sock)
    print("Ending user input thread.")
    
    stopRecv = True #Stops recieve thread
    receiveThread.join()
    
    print("Ending wallet program.")

    
    


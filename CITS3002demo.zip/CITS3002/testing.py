#Isaac R. Ward
#Run on linux with 'python3 testing.py'

from crypto3002 import *

#Main code
if __name__ == '__main__':
    #In the wallet, generate info for two users and construct a message and send
    genRSAKeyPairs("Y")
    genRSAKeyPairs("Z")

    '''
    #Verification testing
    #Test a message that should be false
    m = buildTransaction("privateA.pem", "publicA.pem", "publicB.pem", 10)
    m['amount'] = "5"
    verifyTransaction(m, "publicA.pem")

    #Test a message that should verify
    m = buildTransaction("privateB.pem", "publicB.pem", "publicA.pem", 20)
    m = verifyTransaction(m, "publicB.pem")
    '''
    
	#Integer that hash needs to be less than 
    target = 2**253	#(hard) 0 < target < 2**256 (easy)
    requiredTime = 20	    #Seconds
    numberPerBatch = 20     #Number of hashes required before recalculating target

    totaltime = 0.0
    amount = 0.0
	
    while(True):
    	timelog = []
    	
    	#In the miner, do proof of work algorithm on given message
    	for i in range(0, numberPerBatch - 1):
            m = buildTransaction("privateY.pem", "publicY.pem", "publicZ.pem", amount)
            amount = amount + 1
            metrics = {}
            mine(m, target, metrics)
            
            print("Crypto hash cracked in " + str(metrics['c']) + " hashes w/ nonce " + str(metrics['n']) + " in time: " + str(metrics['n']))
            timelog.append(metrics['t'])
    	
    	totaltime = sum(timelog)
    	target = int(target/(requiredTime*numberPerBatch/totaltime))
    	
    	print("Total time to crack hashes: " + str(totaltime))
    	print(str(requiredTime*numberPerBatch/totaltime)+ " times too easy, \nnew difficulty = " + str(target))



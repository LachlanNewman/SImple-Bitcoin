#Karl Chen Meng
#Isaac R. Ward

import json

blockchain = []                 #Mined transaction list essentially

#Creates a block from successful mining data
def makeBlock(miningData):
    block = {}
    
    #Get the last block's hash, unless this is the first block
    if(len(blockchain) != 0):
        block['prevHash'] = blockchain[len(blockchain) - 1]['hash']
    else:
        block['prevHash'] = "undefined"
    
    #Get the new block's height
    block['height'] = len(blockchain) + 1
    
    #Read in other details require by block
    block['transaction'] = miningData['transaction']
    block['miner'] = miningData['miner']
    block['hash'] = miningData['metrics']['d']
    block['nonce'] = miningData['metrics']['n']
    block['time spent mining'] = miningData['metrics']['t']
    
    return block
    
#Prints visual representation of the blockchain
def printBlockchain():
    print("===========================[ START BLOCKCHAIN ]===========================")
    
    for b in blockchain:
        print("================================[ BLOCK " + str(b['height']) + " ]================================")
        print(json.dumps(b, indent = 4))
        
    print("============================[ END BLOCKCHAIN ]============================")
    
#Prints visual representation of the blockchain using file names rather than key strings when possible
def printBlockchainWithFileNames(fileKeyPairs):
    print("===========================[ START BLOCKCHAIN ]===========================")
    
    for b in blockchain:
        print("================================[ BLOCK " + str(b['height']) + " ]================================")
        #If the printer has the miner's public key string saved as a file, print the file instead
        tmpMiner = b['miner']
        tmpSrc = b['transaction']['srcPubKey']
        tmpDest = b['transaction']['destPubKey']
        
        for p in fileKeyPairs:
            #Replace where miner public key is displayed in block
            if b['miner'] == p['string']:
                b['miner'] = p['file']
            
            #Replace where src & dest public keys are displayed in transactions with file names
            if b['transaction']['srcPubKey'] == p['string']:
                b['transaction']['srcPubKey'] = p['file']
                
            if b['transaction']['destPubKey'] == p['string']:
                b['transaction']['destPubKey'] = p['file']
        
        #Print with altered string
        print(json.dumps(b, indent = 4))
        
        #Put strings back
        b['miner'] = tmpMiner
        b['transaction']['srcPubKey'] = tmpSrc
        b['transaction']['destPubKey'] = tmpDest
        
    print("============================[ END BLOCKCHAIN ]============================")


